# iLearned Learning Management System 
About this project, this helps students train programs and tutors on how to teach online their work in regards to uploading a lesson in the website. 
Learning Management Systems (LMS) have emerged as a game-changer in the way organizations approach training. It has enabled them to create and deliver training programs while being able to efficiently track their employee's progress. A learning management system is a software application for the administration, documentation, tracking, reporting, automation, and delivery of educational courses, training programs, materials or learning and development programs. The learning management system concept emerged directly from e-Learning. 

Features: Customized learning
